# -*- coding: utf-8 -*-


class Parser(object):
    data = None
