class ApiClientException(Exception):
    """Exception for Api Client."""
    pass
